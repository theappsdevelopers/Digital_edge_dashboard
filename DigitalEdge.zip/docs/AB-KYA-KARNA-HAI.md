# Ab kya karna hai – Preview = Dev DB, Live = Prod DB (same API URL)

Base URL dono pe same rahega. Backend header se decide karega kaunsi DB use karni hai.

---

## Tum (backend / AWS) – ye karo

### 1. AWS Elastic Beanstalk pe env variable

- **Ek hi env var:** `MONGODB_URI`
- **Value:** Apna Atlas URI, koi bhi ek DB ke saath, jaise:
  ```text
  mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/digital_edge_prod?retryWrites=true
  ```
- Preview aur production **dono** EB environments pe **yahi same** `MONGODB_URI` daal sakte ho (ek hi cluster, backend apne aap dev/prod DB name use karega).

### 2. Backend deploy

- Jo code ab repo me hai (header se DB switch + single `MONGODB_URI`) wahi deploy karo.
- **Ek hi** backend URL dono ke liye: e.g. `https://api.theappsdevelopers.com`

### 3. Verify

- Deploy ke baad koi bhi API call karo (e.g. login).
- Response headers me **`X-DigitalEdge-DB`** dekho:
  - Preview / dev request pe: `digital_edge_dev`
  - Live request pe: `digital_edge_prod`

Backend side pe bas itna hi. Baaki **Base44 (frontend)** pe hai.

---

## Base44 (frontend) – unhe ye karna hai

**Har API request** pe ek header bhejna zaroori hai, taaki backend ko pata chale preview pe ho ya live. **X-Environment use karo** (NODE_ENV mat – preview build pe bhi NODE_ENV=production hota hai):

| App jahan chal raha hai | Header name      | Header value   |
|-------------------------|------------------|----------------|
| **Preview**             | `X-Environment`  | `preview` ya `development` |
| **Live / Production**   | `X-Environment`  | `production`   |

- **Base URL:** dono jagah same, e.g. `https://api.theappsdevelopers.com`
- **Preview vs Live:** URL/hostname se set karo (e.g. `financedashboard.thedigitaledgetechnologies.com` = preview → `preview`, live domain → `production`). Build ka NODE_ENV mat use karo.

**Example (concept):**

```js
// URL/hostname se – NODE_ENV mat use karo (preview pe bhi production hota hai)
const isLive = window.location.hostname === 'app.theappsdevelopers.com'; // live domain

// Har API call me
headers: {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`,
  'X-Environment': isLive ? 'production' : 'preview',
}
```

Agar header nahi bhejenge to backend **default `development`** maan lega (yani `digital_edge_dev`). Live pe **zaroor `X-Environment: production`** bhejna hoga.

---

## Short summary

| Kis cheez pe | Kya karna hai |
|--------------|----------------|
| **AWS (tum)** | Sirf `MONGODB_URI` set karo, backend deploy karo. Same URL dono environments ke liye. |
| **Backend (tum)** | Kuch aur nahi – code already header se dev/prod switch karta hai. |
| **Base44 (frontend)** | Har request pe **`X-Environment: preview`** (preview) ya **`X-Environment: production`** (live) header bhejna. Base URL same rahega. **NODE_ENV mat bhejo** – preview build pe bhi production hota hai. |

Jab Base44 har request pe sahi header bhejne lage, tab **preview = dev DB, live = prod DB** automatically ho jayega, bina do alag base URL banaye.
