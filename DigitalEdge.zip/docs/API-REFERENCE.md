# DigitalEdge Backend – API Reference (Base44 Integration)

**Base URL:** `http://localhost:4000` (or your deployed backend URL)

---

## 1. Authentication (JWT Bearer)

- **Single admin only.** No signup. Credentials from env: `ADMIN_EMAIL`, `ADMIN_PASSWORD`.
- **Login** returns a JWT. Use it in the **Authorization** header for all protected APIs.

### How to send JWT on protected requests

For every request to a **protected** endpoint, add this header:

```http
Authorization: Bearer <token>
```

Example (raw HTTP):

```http
GET /api/clients HTTP/1.1
Host: localhost:4000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

Example (JavaScript fetch):

```js
fetch('http://localhost:4000/api/clients', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  },
});
```

- **Without token or invalid/expired token:** response `401 Unauthorized` with body `{ "error": "Authentication required" }` or `{ "error": "Invalid or expired token" }`.
- **Public endpoints** (no Bearer needed): `GET /health`, `POST /api/auth/login`.

---

## 2. Endpoints Overview

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/health` | No | Health check |
| POST | `/api/auth/login` | No | Admin login, returns JWT |
| GET | `/api` | Bearer | Welcome message |
| GET | `/api/clients` | Bearer | List clients |
| GET | `/api/projects` | Bearer | List projects |
| GET | `/api/payments` | Bearer | List payments |
| GET | `/api/expenses` | Bearer | List expenses |
| GET | `/api/milestones` | Bearer | List milestones |
| POST | `/api/forecast` | Bearer | Generate revenue/expense forecasts |

---

## 3. Request / Response Details

### 3.1 Health (no auth)

**GET** `/health`

- **Headers:** none required.
- **Body:** none.
- **Response (200):**

```json
{
  "status": "ok",
  "service": "digitaledge-backend",
  "timestamp": "2026-02-17T12:00:00.000Z"
}
```

---

### 3.2 Login (no auth)

**POST** `/api/auth/login`

- **Headers:** `Content-Type: application/json`
- **Body:**

```json
{
  "email": "admin",
  "password": "admin"
}
```

- **Success (200):**

```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "email": "admin",
    "role": "admin"
  }
}
```

- **Error (401):**

```json
{
  "error": "Invalid email or password"
}
```

- **Usage:** Store `token` and send as `Authorization: Bearer <token>` on all protected calls.

---

### 3.3 Welcome (protected)

**GET** `/api`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):**

```json
{
  "message": "Welcome to the DigitalEdge API"
}
```

---

### 3.4 List Clients (protected)

**GET** `/api/clients`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):** array of clients (Base44-compatible shape)

```json
[
  {
    "id": "6799f6b8c1b8c2b8a4a1e001",
    "name": "Acme Corp",
    "industry": "Technology",
    "status": "Active",
    "start_date": "2025-01-10T00:00:00.000Z"
  }
]
```

---

### 3.5 List Projects (protected)

**GET** `/api/projects`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):**

```json
[
  {
    "id": "6799f72bc1b8c2b8a4a1e010",
    "name": "Website Redesign",
    "client_id": "6799f6b8c1b8c2b8a4a1e001",
    "total_value": 50000,
    "start_date": "2025-02-01T00:00:00.000Z",
    "end_date": "2025-06-30T00:00:00.000Z",
    "status": "In Progress",
    "description": "Corporate website revamp",
    "notes": "Phase 1 approved"
  }
]
```

---

### 3.6 List Payments (protected)

**GET** `/api/payments`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):**

```json
[
  {
    "id": "6799f7a3c1b8c2b8a4a1e020",
    "client_id": "6799f6b8c1b8c2b8a4a1e001",
    "project_id": "6799f72bc1b8c2b8a4a1e010",
    "milestone_id": null,
    "amount": 15000,
    "payment_date": "2025-03-05T00:00:00.000Z",
    "month": "2025-03",
    "quarter": "2025-Q1",
    "year": 2025,
    "payment_method": "Bank Transfer",
    "reference_number": "INV-2025-001",
    "notes": "Initial deposit"
  }
]
```

---

### 3.7 List Expenses (protected)

**GET** `/api/expenses`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):**

```json
[
  {
    "id": "6799f812c1b8c2b8a4a1e030",
    "expense_type": "Salary",
    "category": "Engineering",
    "amount": 20000,
    "date": "2025-03-01T00:00:00.000Z",
    "month": "2025-03",
    "quarter": "2025-Q1",
    "year": 2025,
    "vendor": "Internal Payroll",
    "description": "Monthly salaries",
    "receipt_url": null
  }
]
```

**`expense_type` enum:** `Salary`, `Office`, `Marketing`, `Operations`, `Software`, `Travel`, `Professional Services`, `Utilities`, `Other`

---

### 3.8 List Milestones (protected)

**GET** `/api/milestones`

- **Headers:** `Authorization: Bearer <token>`
- **Body:** none.
- **Response (200):**

```json
[
  {
    "id": "6799f86cc1b8c2b8a4a1e040",
    "name": "Design Phase Complete",
    "project_id": "6799f72bc1b8c2b8a4a1e010",
    "value": 25000,
    "due_date": "2025-04-15T00:00:00.000Z",
    "status": "Pending",
    "description": "Deliver full design system"
  }
]
```

**`status` enum:** `Pending`, `Partially Paid`, `Paid`

---

### 3.9 Generate Forecast (protected)

**POST** `/api/forecast`

- **Headers:**  
  `Authorization: Bearer <token>`  
  `Content-Type: application/json`
- **Body:**

```json
{
  "scenario": "baseline",
  "months_ahead": 12,
  "assumptions": {
    "expected_revenue_per_month": 0,
    "expected_expenses_per_month": 0
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `scenario` | string | No | Default `"baseline"`. e.g. baseline, optimistic, pessimistic |
| `months_ahead` | number | No | Default `12`. Number of future months to forecast |
| `assumptions.expected_revenue_per_month` | number | No | Override trend with fixed monthly revenue |
| `assumptions.expected_expenses_per_month` | number | No | Override with fixed monthly expenses |

- **Success (200):**

```json
{
  "success": true,
  "message": "Generated 12 revenue and 36 expense forecasts for scenario: baseline",
  "months_ahead": 12,
  "scenario": "baseline"
}
```

- **Error (500):** `{ "error": "<message>" }`

---

## 4. Planned Create Endpoints (payloads for Base44)

When these routes are implemented, use the same **Authorization: Bearer &lt;token&gt;** header and **Content-Type: application/json**. Payloads below are the contract.

---

### 4.1 Create Client

**POST** `/api/clients` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "name": "Acme Corp",
  "industry": "Technology",
  "status": "Active",
  "startDate": "2025-01-10",
  "phone": "+1 555-1234",
  "contactName": "John Doe",
  "contactEmail": "john@acme.com",
  "notes": "Priority client",
  "assignedUserId": "6799f6b8c1b8c2b8a4a1e100",
  "archived": false
}
```

**`industry` enum:** Technology, Healthcare, Finance, Retail, Manufacturing, Education, Real Estate, Consulting, Media, Other  
**`status` enum:** Active, On Hold, Completed, Churned

---

### 4.2 Create Project

**POST** `/api/projects` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "clientId": "6799f6b8c1b8c2b8a4a1e001",
  "name": "Website Redesign",
  "totalValue": 50000,
  "startDate": "2025-02-01",
  "endDate": "2025-06-30",
  "status": "In Progress",
  "description": "Corporate website revamp",
  "notes": "Phase 1 approved"
}
```

**`status` enum:** Not Started, In Progress, On Hold, Completed, Cancelled

---

### 4.3 Create Employee

**POST** `/api/employees` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "name": "Jane Smith",
  "role": "Senior Engineer",
  "department": "Engineering",
  "employmentType": "Full-time",
  "monthlyCost": 8000,
  "startDate": "2024-11-01",
  "endDate": null,
  "status": "Active",
  "email": "jane.smith@digitaledge.com"
}
```

**`department` enum:** Engineering, Design, Sales, Marketing, Operations, Finance, HR, Executive, Other  
**`employmentType` enum:** Full-time, Part-time, Contract, Freelance  
**`status` enum:** Active, Inactive, On Leave

---

### 4.4 Create Payment

**POST** `/api/payments` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "clientId": "6799f6b8c1b8c2b8a4a1e001",
  "projectId": "6799f72bc1b8c2b8a4a1e010",
  "milestoneId": null,
  "amount": 15000,
  "paymentDate": "2025-03-05",
  "month": "2025-03",
  "quarter": "2025-Q1",
  "year": 2025,
  "paymentMethod": "Bank Transfer",
  "referenceNumber": "INV-2025-001",
  "notes": "Initial deposit"
}
```

**`paymentMethod` enum:** Bank Transfer, Check, Credit Card, Cash, Other

---

### 4.5 Create Expense

**POST** `/api/expenses` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "expenseType": "Salary",
  "category": "Engineering",
  "amount": 20000,
  "date": "2025-03-01",
  "month": "2025-03",
  "quarter": "2025-Q1",
  "year": 2025,
  "vendor": "Internal Payroll",
  "description": "Monthly salaries",
  "receiptUrl": null
}
```

**`expenseType`:** same enum as list expenses.

---

### 4.6 Create Milestone

**POST** `/api/milestones` (to be implemented)

**Headers:** `Authorization: Bearer <token>`, `Content-Type: application/json`

**Body:**

```json
{
  "name": "Design Phase Complete",
  "projectId": "6799f72bc1b8c2b8a4a1e010",
  "value": 25000,
  "dueDate": "2025-04-15",
  "status": "Pending",
  "description": "Deliver full design system"
}
```

---

## 5. Error Responses (common)

- **401 Unauthorized**  
  - Missing/invalid/expired token: `{ "error": "Authentication required" }` or `{ "error": "Invalid or expired token" }`  
  - Login failure: `{ "error": "Invalid email or password" }`
- **500 Internal Server Error**  
  - `{ "error": "<message>" }`

---

## 6. Quick Integration Checklist (Base44)

1. **Base URL** – Set to backend URL (e.g. `http://localhost:4000` or production).
2. **Login once** – `POST /api/auth/login` with `{ "email": "admin", "password": "admin" }`, store `response.token`.
3. **All other API calls** – Send header `Authorization: Bearer <stored_token>`.
4. **List data for Dashboard** – GET `/api/clients`, `/api/projects`, `/api/payments`, `/api/expenses`, `/api/milestones` (all with Bearer).
5. **Forecast** – `POST /api/forecast` with body above, with Bearer.
6. **Create endpoints** – When backend adds them, use the payloads in Section 4 with the same Bearer header.
