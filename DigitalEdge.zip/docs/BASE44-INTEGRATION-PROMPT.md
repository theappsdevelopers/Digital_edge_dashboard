# Base44 – DigitalEdge Backend Integration (Kya karna hai)

Yeh document Base44 frontend team ke liye hai. Isko follow karke tum backend se sahi tarah connect kar sakte ho aur **preview** vs **live** dono pe sahi database use hogi.

---

## 1. API URL (same for preview & live)

- **Base URL:** `https://api.theappsdevelopers.com` (production / preview dono ke liye same)
- Koi alag URL mat use karo preview ke liye; backend **header** se samajh jata hai tum preview pe ho ya live.

---

## 2. Zaroori: Har request pe DB choose karne ke liye header bhejo

Backend **database** isi header se decide karta hai. **X-Environment use karo** (NODE_ENV mat bhejo – preview build pe bhi NODE_ENV=production hota hai, isliye galat DB use ho jati hai).

| Tum kahan ho   | Header name      | Header value   | Backend ka DB           |
|----------------|------------------|----------------|--------------------------|
| **Preview**    | `X-Environment`  | `preview` ya `development` | `digital_edge_dev`      |
| **Live/Prod**  | `X-Environment` | `production`   | `digital_edge_prod`     |

**Kya karna hai:**

- **Preview** pe **har API request** pe: `X-Environment: preview` (ya `development`).
- **Live** pe: `X-Environment: production`.
- **NODE_ENV mat bhejo** – Vercel/Netlify preview pe bhi NODE_ENV=production hota hai, isliye backend prod DB use kar leta tha. **Sirf X-Environment** use karo, aur value **URL/hostname** se set karo (e.g. preview domain → preview, live domain → production).

**Example (fetch):**

```js
// URL se decide karo – NODE_ENV mat use karo (preview build pe bhi production hota hai)
const isLive = window.location.hostname === 'app.theappsdevelopers.com'; // ya jo live domain ho

fetch('https://api.theappsdevelopers.com/api/clients', {
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
    'X-Environment': isLive ? 'production' : 'preview',
  },
});
```

Backend har response me **`X-DigitalEdge-DB`** header bhejta hai: `digital_edge_dev` ya `digital_edge_prod`. Browser DevTools → Network me response headers check karo — preview pe `digital_edge_dev` dikhna chahiye.

**Example (axios):**

```js
// Base URL / hostname se set karo
const isLive = window.location.hostname === 'app.theappsdevelopers.com';
axios.defaults.headers.common['X-Environment'] = isLive ? 'production' : 'preview';
```

Agar header nahi bheloge, backend default **development** maan lega (yani `digital_edge_dev`). Isliye **live pe zaroor `production` bhejna**.

---

## 3. Auth (login + token)

- **Login:** `POST https://api.theappsdevelopers.com/api/auth/login`  
  Body: `{ "email": "admin", "password": "admin" }` (ya jo credentials backend team de)  
  Response me **token** aata hai.
- **Baaki saari API calls** pe ye header add karo:  
  `Authorization: Bearer <token>`
- `/health` aur `/api/auth/login` pe token zaroori nahi.

---

## 4. CORS

Backend already **NODE_ENV** header allow karta hai. Sirf ensure karo tum **har request** pe ye header bhej rahe ho (point 2).

---

## 5. Short checklist (Base44)

1. Base URL fix karo: `https://api.theappsdevelopers.com`
2. **Har API request** pe (login ke alawa):
   - `Authorization: Bearer <token>`
   - **`X-Environment: preview`** (preview) ya **`X-Environment: production`** (live) — **NODE_ENV mat bhejo**, preview build pe bhi production hota hai
3. Preview pe kabhi bhi `X-Environment: production` mat bhejo — warna preview bhi prod DB use karne lag jayega.
4. Full API list aur payloads ke liye repo me `docs/API-REFERENCE.md` dekho.

---

## 6. Copy-paste prompt (agar kisi ko text me bhejna ho)

```
DigitalEdge backend use karte waqt:

1) API base URL: https://api.theappsdevelopers.com (preview aur live dono ke liye same).

2) Har API request pe X-Environment header bhejna zaroori hai (NODE_ENV mat bhejo – preview build pe bhi production hota hai):
   - Preview: X-Environment = "preview" (ya "development")
   - Live: X-Environment = "production"
   Value URL/hostname se set karo (e.g. preview domain → preview, live domain → production).

3) Login: POST /api/auth/login with { email, password }, response me token aata hai.
   Baaki sab endpoints pe header: Authorization: Bearer <token>.

4) Full API reference: docs/API-REFERENCE.md.
```

---

Is hisaab se Base44 pe **preview pe dev DB** aur **live pe prod DB** use hogi, bina URL change kiye.
