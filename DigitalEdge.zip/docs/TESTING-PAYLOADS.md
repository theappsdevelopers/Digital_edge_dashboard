# DigitalEdge API – Testing Payloads & Endpoints

**Base URL:** `https://api.theappsdevelopers.com` (or `http://localhost:4000`)

Replace `BASE` and `TOKEN` in examples below.

---

## 1. Get token (login)

**POST** `BASE/api/auth/login`  
**Auth:** None

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "email": "admin",
  "password": "admin"
}
```

**Sample response (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": { "email": "admin", "role": "admin" }
}
```
→ Copy `token` and use as `TOKEN` in all protected requests below.

---

## 2. Health (no auth)

**GET** `BASE/health`  
**Body:** none

**Response (200):**
```json
{
  "status": "ok",
  "service": "digitaledge-backend",
  "timestamp": "2026-02-17T12:00:00.000Z"
}
```

---

## 3. Protected endpoints – common header

For all below (except health & login), add:

**Headers:**
```
Authorization: Bearer TOKEN
Content-Type: application/json
```
(Use `Content-Type` only for POST/PUT bodies.)

---

## 4. List APIs (GET, no body)

| Method | Endpoint | Body |
|--------|----------|------|
| GET | `BASE/api` | none |
| GET | `BASE/api/clients` | none |
| GET | `BASE/api/projects` | none |
| GET | `BASE/api/payments` | none |
| GET | `BASE/api/expenses` | none |
| GET | `BASE/api/milestones` | none |

---

## 5. Create client

**POST** `BASE/api/clients`

**Headers:** `Authorization: Bearer TOKEN`, `Content-Type: application/json`

**Body:**
```json
{
  "name": "brooks hub",
  "industry": "Technology",
  "start_date": "2026-02-27",
  "status": "Active",
  "contact_name": "brooks hub",
  "contact_email": "",
  "notes": ""
}
```

**Minimal body (required only):**
```json
{
  "name": "Acme Corp",
  "industry": "Technology"
}
```

**Optional fields:** `start_date`, `status`, `contact_name`, `contact_email`, `notes`, `phone`, `assignedUserId`, `archived`

**Response (201):**
```json
{
  "id": "6799f6b8c1b8c2b8a4a1e001",
  "name": "brooks hub",
  "industry": "Technology",
  "status": "Active",
  "start_date": "2026-02-27T00:00:00.000Z",
  "contact_name": "brooks hub",
  "contact_email": "",
  "notes": ""
}
```

---

## 6. Generate forecast

**POST** `BASE/api/forecast`

**Headers:** `Authorization: Bearer TOKEN`, `Content-Type: application/json`

**Body:**
```json
{
  "scenario": "baseline",
  "months_ahead": 12,
  "assumptions": {
    "expected_revenue_per_month": 0,
    "expected_expenses_per_month": 0
  }
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Generated 12 revenue and 36 expense forecasts for scenario: baseline",
  "months_ahead": 12,
  "scenario": "baseline"
}
```

---

## 7. cURL examples

**Login (save token manually):**
```bash
curl -X POST "https://api.theappsdevelopers.com/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin","password":"admin"}'
```

**List clients (replace TOKEN):**
```bash
curl -X GET "https://api.theappsdevelopers.com/api/clients" \
  -H "Authorization: Bearer TOKEN"
```

**Create client:**
```bash
curl -X POST "https://api.theappsdevelopers.com/api/clients" \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"brooks hub","industry":"Technology","start_date":"2026-02-27","status":"Active","contact_name":"brooks hub","contact_email":"","notes":""}'
```

**Generate forecast:**
```bash
curl -X POST "https://api.theappsdevelopers.com/api/forecast" \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"scenario":"baseline","months_ahead":12,"assumptions":{"expected_revenue_per_month":0,"expected_expenses_per_month":0}}'
```

---

## 8. Quick checklist

| # | Method | Endpoint | Body |
|---|--------|----------|------|
| 1 | POST | `/api/auth/login` | `{"email":"admin","password":"admin"}` |
| 2 | GET | `/health` | — |
| 3 | GET | `/api` | — |
| 4 | GET | `/api/clients` | — |
| 5 | GET | `/api/projects` | — |
| 6 | GET | `/api/payments` | — |
| 7 | GET | `/api/expenses` | — |
| 8 | GET | `/api/milestones` | — |
| 9 | POST | `/api/clients` | Client JSON (see §5) |
| 10 | POST | `/api/forecast` | Forecast JSON (see §6) |

All except #1 and #2 need header: `Authorization: Bearer <token>`.
